<script lang="ts">
    import PractitionerLaunch from "./lib/PractitionerLaunch.svelte";
  
</script>

<main>
  <PractitionerLaunch></PractitionerLaunch>
  Main Content!!!
</main>